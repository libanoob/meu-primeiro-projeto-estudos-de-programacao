/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade.de.vetores.pkg2;

import java.util.Arrays;
import java.util.Scanner;
public class AtividadeDeVetores2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Scanner teclado = new Scanner(System.in);
    
    int[] numeros = new int[10];
    
        System.out.println("digite 10 numeros aleatorios: ");
    for (int in = 0; in <10; in++) {
        System.out.println((in+1 ) + "numero: ");
        numeros[in] = teclado.nextInt(); }
        
            Arrays.sort(numeros);
        for (int i = 0; i< numeros.length; i++) {
            System.out.println(numeros[i]);
        }
    }
    }
    

