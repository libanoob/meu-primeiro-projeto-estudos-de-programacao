/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade.de.prog;

import java.util.Scanner;
public class AtividadeDeProg {


    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
       
        double soma = 0;
        int indice= 0;
                double media;
        double [] notas = new double [10];
       String turma;
        String [] nomes = new String [10];
       
       
       
        System.out.println("=== Mural de notas dos alunos ===");
        System.out.println("Ola professor, para qual tuma voce deseja colocar a nota? ");
        turma = teclado.nextLine();
        System.out.println("==== " +turma + " =====");
         int op = 0;
        do {
         
           System.out.println("Aluno " +(indice + 1 ) + ":");
           nomes[indice] = teclado.nextLine();

           teclado.nextLine();
           
            System.out.println("nota de " +nomes[indice] +": ");
            notas [indice]= teclado.nextDouble();
            
            if (notas [indice] <0) {
                System.out.println("Nota invalida");
            }
            else if (notas [indice] >10) {
                   System.out.println("Nota inválida");
                   break;
            }
            
            
            
            soma+= notas[indice];

            if (indice <10) {
               System.out.println("Deseja cadastrar mais alguem? 1-sim 0-nao");
                op = teclado.nextInt();

            } else {
                System.out.println("10 alunos cadastrados!");
                op = 0;
            }
            indice++;
        }  while (op == 1);

       media = soma / indice;
       
            System.out.println("=== MURAL DE NOTAS ===");
            System.out.println("==== " +turma + " ====");
           
            for (int i = 0;  i< indice; i++) {
                System.out.println(nomes[i]+" "+notas[i] + ":"); }
           
            System.out.println("media da turma eh: " +media);
            }

   
    }
